import {
  IndianRupee,
  ShieldCheck,
  Star,
  Zap,
  DollarSign,
  BarChart3,
  Check,
  ArrowRight,
} from "lucide-react";

export default function WhyChooseDigitalGold() {
  return (
    <section className="bg-white py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-orange-50 px-4 py-1 text-sm font-medium text-orange-600">
            ⚡ Why Choose Digital Gold
          </span>

          <h2 className="mt-6 text-4xl font-extrabold text-slate-900">
            Smart Gold Investment for Modern India
          </h2>

          <p className="mx-auto mt-4 max-w-2xl text-slate-600">
            Experience the future of gold investment with complete transparency,
            security, and convenience
          </p>
        </div>

        {/* Grid */}
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {/* Start with ₹10 */}
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-100">
              <IndianRupee className="text-yellow-600" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              Start with Just ₹10
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Begin your gold investment journey without traditional minimum
              purchase barriers. Build wealth systematically with
              micro-investments.
            </p>
            <button className="mt-4 text-sm font-semibold text-yellow-600 hover:underline">
              Micro-investing enabled →
            </button>
          </div>

          {/* Bank-Grade Security */}
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-100">
              <ShieldCheck className="text-green-600" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              Bank-Grade Security
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Your gold is stored in climate-controlled, high-security vaults
              with 24/7 surveillance and comprehensive insurance coverage.
            </p>
            <button className="mt-4 text-sm font-semibold text-green-600 hover:underline">
              Fully insured & audited →
            </button>
          </div>

          {/* 24K Pure Gold (Highlighted) */}
          <div className="rounded-2xl bg-gradient-to-br from-yellow-50 to-orange-50 p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-yellow-500">
              <Star className="text-white" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              24K Pure Gold (99.99%)
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Invest in BIS Hallmark certified, MMTC-PAMP sourced gold with
              guaranteed purity and authenticity.
            </p>

            <ul className="mt-4 space-y-2 text-sm text-slate-700">
              <li className="flex items-center gap-2">
                <Check className="text-green-600" size={14} />
                LBMA Accredited Sources
              </li>
              <li className="flex items-center gap-2">
                <Check className="text-green-600" size={14} />
                BIS Hallmark Certified
              </li>
            </ul>
          </div>

          {/* Instant Liquidity */}
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100">
              <Zap className="text-blue-600" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              Instant Liquidity
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Buy or sell your gold 24/7 at live market rates. Funds are credited
              to your account within 2–3 working days.
            </p>
            <button className="mt-4 text-sm font-semibold text-blue-600 hover:underline">
              24/7 trading available →
            </button>
          </div>

          {/* Zero Hidden Charges */}
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-100">
              <DollarSign className="text-purple-600" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              Zero Hidden Charges
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              No making charges, wastage fees, or storage costs. Transparent
              pricing with minimal buy-sell spreads.
            </p>
            <button className="mt-4 text-sm font-semibold text-purple-600 hover:underline">
              Complete transparency →
            </button>
          </div>

          {/* Gold SIP */}
          <div className="rounded-2xl bg-slate-50 p-6 shadow-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500">
              <BarChart3 className="text-white" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-slate-900">
              Gold SIP Available
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Start systematic investment plans from ₹100/month. Benefit from
              rupee cost averaging during price fluctuations.
            </p>

            <ul className="mt-4 space-y-2 text-sm text-slate-700">
              <li className="flex items-center gap-2">
                <Check className="text-green-600" size={14} />
                Automated Investments
              </li>
              <li className="flex items-center gap-2">
                <Check className="text-green-600" size={14} />
                Flexible Amount & Frequency
              </li>
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <button className="inline-flex items-center gap-2 rounded-full bg-yellow-500 px-8 py-4 font-semibold text-white transition hover:bg-yellow-600">
            Start Your Gold Investment Journey
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
