export default function DigitalGoldStats() {
  return (
    <section className="bg-white py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Top Badge */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-yellow-300 bg-yellow-50 px-4 py-1 text-sm font-medium text-yellow-700">
            ⭐ India&apos;s Digital Gold Market Leader
          </span>

          <h2 className="mt-6 text-4xl font-extrabold text-slate-900">
            Trusted Digital Gold Investment Platform
          </h2>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 gap-12 text-center md:grid-cols-4">
          <div>
            <p className="text-5xl font-extrabold text-yellow-600">₹1.8B+</p>
            <p className="mt-2 text-slate-600">
              Market Value (2024)
            </p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-yellow-600">6M+</p>
            <p className="mt-2 text-slate-600">
              Active Investors
            </p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-yellow-600">65%</p>
            <p className="mt-2 text-slate-600">
              YoY Growth Rate
            </p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-yellow-600">₹10</p>
            <p className="mt-2 text-slate-600">
              Minimum Investment
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
