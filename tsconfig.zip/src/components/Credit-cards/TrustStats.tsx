import { ShieldCheck } from "lucide-react";

export default function TrustStats() {
  return (
    <section className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-orange-50 px-4 py-1 text-sm font-medium text-orange-600">
            ✔ Trusted by Millions
          </span>

          <h2 className="mt-6 text-4xl font-extrabold text-slate-900">
            India's Most Trusted Financial Platform
          </h2>
        </div>

        {/* Main Stats */}
        <div className="mt-14 grid grid-cols-2 gap-12 text-center md:grid-cols-4">
          <div>
            <p className="text-5xl font-extrabold text-slate-900">2M+</p>
            <p className="mt-2 text-slate-600">Happy Customers</p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-slate-900">90+</p>
            <p className="mt-2 text-slate-600">Partner Banks</p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-slate-900">₹20+</p>
            <p className="mt-2 text-slate-600">Crores Saved</p>
          </div>

          <div>
            <p className="text-5xl font-extrabold text-slate-900">500+</p>
            <p className="mt-2 text-slate-600">Cities Served</p>
          </div>
        </div>

        {/* Divider */}
        <div className="my-20 h-px w-full bg-slate-200" />

        {/* Feature Cards */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="rounded-2xl bg-white p-6 text-center shadow-sm">
            <p className="text-3xl font-extrabold text-orange-500">98%</p>
            <p className="mt-2 text-slate-600">Customer Satisfaction</p>
          </div>

          <div className="rounded-2xl bg-white p-6 text-center shadow-sm">
            <p className="text-3xl font-extrabold text-orange-500">24/7</p>
            <p className="mt-2 text-slate-600">Support Available</p>
          </div>

          <div className="rounded-2xl bg-white p-6 text-center shadow-sm">
            <p className="text-3xl font-extrabold text-orange-500">3 Min</p>
            <p className="mt-2 text-slate-600">Avg Response Time</p>
          </div>

          <div className="rounded-2xl bg-white p-6 text-center shadow-sm">
            <p className="text-3xl font-extrabold text-orange-500">100%</p>
            <p className="mt-2 text-slate-600">Secure & Private</p>
          </div>
        </div>

        {/* Compliance */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-8 text-sm text-slate-600">
          <div className="flex items-center gap-2">
            <ShieldCheck className="text-green-600" size={18} />
            Banks Compliant
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="text-green-600" size={18} />
            ISO 27001 Certified
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="text-green-600" size={18} />
            256-bit Encryption
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="text-green-600" size={18} />
            SOC 2 Compliant
          </div>
        </div>
      </div>
    </section>
  );
}
