import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import _1920wLight from './pages/Home';
import Creditscore from './pages/credit-score/page.js';
import Creditcards from './pages/Credit-cards/page.js';
import Digitalgold from './pages/Digital-gold/page.js';
import Blog from './pages/Blog/page.js';


function App() {
  return (
    <BrowserRouter>
        <Routes>
			<Route path="/" element={<_1920wLight />} />
			<Route path="/_1920wLight" element={<_1920wLight />} />
        </Routes>
          <Routes>
			<Route path="/" element={<credit-score />} />
			<Route path="/credit-score" element={<Creditscore />} />
        </Routes>
         <Routes>
			<Route path="/" element={<Credit-cards />} />
			<Route path="/Credit-cards" element={<Creditcards />} />
        </Routes>
         <Routes>
			<Route path="/" element={<Credit-cards />} />
			<Route path="/Digital-gold" element={<Digitalgold />} />
        </Routes>
         <Routes>
			<Route path="/" element={<Blog />} />
			<Route path="/blog" element={<Blog />} />
        </Routes>
    </BrowserRouter>
  );
}
export default App;