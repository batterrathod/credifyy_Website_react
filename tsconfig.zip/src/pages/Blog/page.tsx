import Header from "../../components/layout/Header";
import Footer from "../../components/layout/Footer";

import Hero from "../../components/Blog/Hero";
import Blogs from "../../components/Blog/Blogs";
import CTA from "../../components/Blog/CTA";


export default function HomePage() {
  return (
    <div className="bg-white overflow-x-hidden">
      <Header />

      <main className="pt-20">
        <Hero />
        <Blogs />
        <CTA />
        
      </main>

      <Footer />
    </div>
  );
}
